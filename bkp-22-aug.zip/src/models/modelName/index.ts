export enum modelName {
    College = "College",
    Course = "Course",
    Faculty = "Faculty",
    Lecture = "Lecture",
    Student = "Student",
    Superadmin = "Superadmin",
    University = "University",
    User = "User",
}